#include "/lib/version.glsl"

#define fsh
#define WORLD_OVERWORLD

#include "/program/gbuffers_main.glsl"
